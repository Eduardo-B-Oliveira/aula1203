import React from 'react';
import './navbar.css';

const Navbar = () => {
  return (
    <div>
      {/* Barra de navegação principal */}
      <nav className="navbar">
        <div className="navbar-logo">Logo</div>
        <ul className="navbar-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">Sobre</a></li>
          <li><a href="#services">Serviços</a></li>
          <li><a href="#contact">Contato</a></li>
        </ul>
      </nav>

      {/* Segunda barra de navegação */}
      <nav className="navbar-second">
        <ul className="navbar-links-second">
          <li><a href="#blog">Blog</a></li>
          <li><a href="#faq">FAQ</a></li>
          <li><a href="#support">Suporte</a></li>
          <li><a href="#shop">Loja</a></li>
        </ul>
      </nav>
    </div>
  );
};

export default Navbar;